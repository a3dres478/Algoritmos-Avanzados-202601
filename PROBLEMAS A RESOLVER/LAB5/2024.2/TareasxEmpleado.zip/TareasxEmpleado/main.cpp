/* 
 * File:   main.cpp
 * Author: cueva
 *
 * Created on 21 de noviembre de 2024, 09:35 PM
 */

#include <iostream>
#include <ctime>
#include <cmath>
#include <algorithm>
#include <vector>
#include <map>
#define N 5
#define NITERACIONES 1000
#define NIND 20
#define Tseleccion 0.5
#define Pcasamiento 0.8
#define Tmutacion 0.1
int gcosto[N][N];

using namespace std;

bool aberracion(vector<int>cromo){
    int total;
    
    for(int i=0;i<N;i++){
        total=0;    
        for(int j=0;j<N;j++)
            total+=cromo[N*j+i];
        if(total!=1)
            return true;
    }
    for(int i=0;i<N;i++){
        total=0;    
        for(int j=0;j<N;j++)
            total+=cromo[N*i+j];
        if(total!=1)
            return true;
    }    
    
    return false;
}

int calculafitness(vector<int> cromo,int costo[][N]){
    int cont=0;
    
    for(int i=0;i<cromo.size();i++){
        int x=i/cromo.size();
        int y=i%cromo.size();
        cont+=cromo[i]*costo[x][y];
    }
    return cont;
    
}

void muestrapoblacion(vector<vector<int>> poblacion,int costo[][N]){
    for(int i=0;i<poblacion.size();i++){
        for(int j=0;j<poblacion[i].size();j++){
            cout << poblacion[i][j] << "  ";
        }
        cout <<" fo="<< calculafitness(poblacion[i],costo) <<endl;
    }
}

void generapoblacioninicial(vector<vector<int>>&poblacion,int costo[][N]){
    int cont=0;
    
    while(cont<NIND){
        vector <int> vaux;
        for(int i=0;i<N*N;i++)
            vaux.push_back(0);   
        for(int i=0;i<N;i++){
            int pos=rand()%N;
            vaux[N*i+pos]=1; 
        }
         if(not aberracion(vaux)){
            poblacion.push_back(vaux);
            cont++;
        }
    }
}    

int muestramejor(vector<vector<int>> poblacion,
        int costo[][N]){
    int mejor=0;
    for(int i=0;i<poblacion.size();i++)
        if(calculafitness(poblacion[mejor],costo)<calculafitness(poblacion[i],costo))
            mejor=i;
    
    cout << endl<<"La mejor solucion es:" << calculafitness(poblacion[mejor],costo)<<endl;
    for(int i=0;i<poblacion[mejor].size();i++){
        cout << poblacion[mejor][i] << "  ";        
    }
    cout << endl;
    return calculafitness(poblacion[mejor],costo);
}

void calculasupervivencia(vector<vector<int>>poblacion,
    vector<int>&supervivencia, int costo[][N]){
    int suma=0;
    
    for(int i=0;i<poblacion.size();i++)
        suma+=calculafitness(poblacion[i],costo);
    for(int i=0;i<poblacion.size();i++){
        int fit= round(100*(double)calculafitness(poblacion[i],costo)/suma);
        supervivencia.push_back(fit);
    }

}

void cargaruleta(vector<int>supervivencia,int *ruleta){
    int ind=0;
    for(int i=0;i<supervivencia.size();i++)
        for(int j=0;j<supervivencia[i];j++)
            ruleta[ind++]=i;
}

void generahijo(vector<int>padre,vector<int>madre,
        vector<int>&hijo){
    int pos=round(padre.size()*Pcasamiento);
//    cout << endl << pos << endl;
    for(int i=0;i<pos;i++)
        hijo.push_back(padre[i]);
    for(int i=pos;i<madre.size();i++)
        hijo.push_back(madre[i]);
}

void casamiento(vector<vector<int>>padres,
        vector<vector<int>>&poblacion){
    for(int i=0;i<padres.size();i++)
        for(int j=0;j<padres.size();j++)
            if(i!=j){
                vector<int>cromo;
                generahijo(padres[i],padres[j],cromo);
                if(!aberracion(cromo)){
                    poblacion.push_back(cromo);
                }    
            }
}


void seleccion(vector<vector<int>>&padres,vector<vector<int>>poblacion,
    int costo[][N]){
    int ruleta[100]{-1};
    vector<int>supervivencia;
    calculasupervivencia(poblacion,supervivencia,costo);
    cargaruleta(supervivencia,ruleta);
    int nseleccionados= poblacion.size()*Tseleccion;        
    for(int i=0;i<nseleccionados;i++){
        int ind=rand()%100;
        if(ruleta[ind]>-1)
            padres.push_back(poblacion[ruleta[ind]]);
            
    } 

}

void inversion(vector<vector<int>>&poblacion,
        vector<vector<int>>padres){
    
    for(int i=0;i<padres.size();i++){
        for(int j=0;j<padres[i].size();j++){
            if(padres[i][j]==0)
                padres[i][j]=1;
            else
                padres[i][j]=0;
        }
        if(!aberracion(padres[i]))
            poblacion.push_back(padres[i]);
    }
    
}

void mutacion(vector<vector<int>> &poblacion,vector<vector<int>> padres){
    int cont=0;
    int n=padres[0].size();
    int nmuta=round(n*Tmutacion);
    for(int i=0;i<padres.size();i++){
        while(cont<nmuta){
            int ind=rand()%padres[0].size();
            if(padres[i][ind]==0){
                padres[i][ind]=1;
            }
            else
                padres[i][ind]=0;
            cont++;
        }
        if(!aberracion(padres[i]))
            poblacion.push_back(padres[i]);     
    }
}

bool compara(vector<int>a,vector<int>b){
    int suma=0,sumb=0;
   
    for(int i=0;i<a.size();i++)
        suma+=calculafitness(a,gcosto);
    for(int i=0;i<b.size();i++)
        sumb+=calculafitness(b,gcosto);
    return suma>sumb;
}
long compacta(vector<int>cromo){
    long num=0;
    for(int i=0;i<cromo.size();i++)
        num+=pow(2,i)*cromo[i];
    return num;
    
}
void eliminaaberraciones(vector<vector<int>> &poblacion){
    map<long,vector<int>> municos;
    
    for(int i=0;i<poblacion.size();i++){
        int num=compacta(poblacion[i]);
        municos[num]=poblacion[i];
    }
    poblacion.clear();
    for(map<long,vector<int>>::iterator it=municos.begin();
            it!=municos.end();it++){
        poblacion.push_back(it->second);
    }
        
    
}


void generarpoblacion(vector<vector<int>> &poblacion,
        int costo[][N]){
    
    for(int i=0;i<N;i++)
        for(int j=0;j<N;j++)
            gcosto[i][j]=costo[i][j];
    sort(poblacion.begin(),poblacion.end(),compara);
    if(poblacion.size()>NIND)
        poblacion.erase(poblacion.begin()+NIND,poblacion.end());
    
}

void mochilaAG(int costo[][N]){
    int cont=0;
    vector<vector<int>> poblacion;
    srand(time(NULL));
    generapoblacioninicial(poblacion,costo);
//    muestrapoblacion(poblacion,costo);    
    cout<<endl;
    while(1){
        vector<vector<int>> padres;
        seleccion(padres,poblacion,costo);
//        muestrapoblacion(padres,costo);  
        cout<<endl;
        casamiento(padres,poblacion);
//        muestrapoblacion(padres,costo);  
        cout << endl;
        inversion(poblacion,padres);
//        muestrapoblacion(padres,costo);  
        cout << endl;
        mutacion(poblacion,padres);
//        muestrapoblacion(padres,costo);  
        cout << endl;
        eliminaaberraciones(poblacion);
//        muestrapoblacion(poblacion,costo);  
        cout << endl;
//        generarpoblacion(poblacion,costo);
//        muestrapoblacion(poblacion,costo); 
        muestramejor(poblacion,costo);
        cont++;
        if(cont==NITERACIONES) break;
    }
}

int main(int argc, char** argv) {
    int costo[N][N]={   {9,2,7,8,6},
                        {6,4,3,7,8},
                        {5,8,1,8,3},
                        {7,6,9,4,2},
                        {8,6,7,5,9}};
    
    mochilaAG(costo);

    return 0;
}

